close all
clear
clc
%z1='E:\thesis\matlab code\GUI\testgui\images\';
z1='D:\Corel\';
z11='D:\New Papers\CISPIS\2019\Jornal';
z3='.jpg';
%z1='E:\thesis\matlab code\gradient\im\';

for ii=1:10000
    ii
    z2=num2str(ii);
    y=char(strcat(z1,z2,z3));
    y2=char(strcat(z11,z2,z3));
    imgrgb=imread(y);
% %     figure
% %     imshow(imgrgb);
    Lbp=efficientLBP(imgrgb); 
%     feature_gradhist(:,ii) = GRAD_gradhist(Lbp); % 

% %     imwrite(Lbp,y2);//New 1398
    F(:,ii)=imhist(Lbp);%%It is threeth algoritm for Hamed Qazanfari
% %     figure
% %     imshow(Lbp);
% %     figure
% %     plot(imhist(Lbp));
    
    
   % feature_gradhist(ii+1,:) = DHSE(imgrgb); % 
end

csvwrite('FeatureHistLBP10k.csv',F);

% csvwrite('FeatureLBPZ10k.csv',feature_gradhist);
% save('datagrad256lbp_1000','feature_gradhist');
%%
%save('DHSE_1000','feature_gradhist');