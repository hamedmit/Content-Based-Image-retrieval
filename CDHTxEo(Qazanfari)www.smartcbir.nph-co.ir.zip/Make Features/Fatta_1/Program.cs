﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Fatta_1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }

    public class ColorSpace
    {


        protected const double BLACK = 20d;
        protected const double YELLOW = 70d;

        public static void RGB2HSV(ref int[,,] RGB, out double[,,] HSV, int wid, int hei)
        {
            int i, j;
            HSV = new double[3, wid, hei];

            for (i = 0; i < wid; i++)
            {
                for (j = 0; j < hei; j++)
                {
                    double var_R, var_G, var_B, var_Min, var_Max, del_Max, del_R, del_G, del_B;
                    var_R = (Convert.ToDouble(RGB[0, i, j]) / 255);        //R from 0 to 255
                    var_G = (Convert.ToDouble(RGB[1, i, j]) / 255);        //G from 0 to 255
                    var_B = (Convert.ToDouble(RGB[2, i, j]) / 255);        //B from 0 to 255

                    var_Min = Math.Min(var_R, var_G);
                    var_Min = Math.Min(var_Min, var_B);   //Min. value of RGB
                    var_Max = Math.Max(var_R, var_G);
                    var_Max = Math.Max(var_Max, var_B);     //Max. value of RGB
                    del_Max = var_Max - var_Min;             //Delta RGB value 

                    HSV[2, i, j] = var_Max;

                    if (del_Max == 0)                     //This is a gray, no chroma...
                    {
                        HSV[0, i, j] = 0;                                //HSV results from 0 to 1
                        HSV[1, i, j] = 0;
                    }
                    else                                    //Chromatic data...
                    {
                        HSV[1, i, j] = del_Max / var_Max;

                        del_R = (((var_Max - var_R) / 6) + (del_Max / 2)) / del_Max;
                        del_G = (((var_Max - var_G) / 6) + (del_Max / 2)) / del_Max;
                        del_B = (((var_Max - var_B) / 6) + (del_Max / 2)) / del_Max;

                        if (var_R == var_Max) HSV[0, i, j] = del_B - del_G;
                        else if (var_G == var_Max) HSV[0, i, j] = (1 / 3) + del_R - del_B;
                        else if (var_B == var_Max) HSV[0, i, j] = (2 / 3) + del_G - del_R;

                        if (HSV[0, i, j] < 0) HSV[0, i, j] += 1;
                        if (HSV[0, i, j] > 1) HSV[0, i, j] -= 1;
                    }

                }
            }
        }

    }

    public class ColorQuantization
    {

        public static void cHSV(ref double[,,] HSV, out int[,] img, int colnum1, int colnum2, int colnum3, int wid, int hei)
        {
            img = new int[wid, hei];


            int L = 0, a = 0, b = 0;

            for (int i = 0; i < wid; i++)
            {
                for (int j = 0; j < hei; j++)
                {
                    L = Convert.ToInt32(HSV[0, i, j] * colnum1);

                    if (L >= (colnum1 - 1))
                    {
                        L = colnum1 - 1;
                    }
                    if (L < 0)
                    {
                        L = 0;
                    }

                    a = Convert.ToInt32((HSV[1, i, j]) * colnum2);
                    if (a >= (colnum2 - 1))
                    {
                        a = colnum2 - 1;
                    }
                    if (a < 0)
                    {
                        a = 0;
                    }

                    b = Convert.ToInt32((HSV[2, i, j]) * colnum3);
                    if (b >= (colnum3 - 1))
                    {
                        b = colnum3 - 1;
                    }
                    if (b < 0)
                    {
                        b = 0;
                    }

                    //-------------------------------------------
                    img[i, j] = (colnum3 * colnum2) * L + colnum3 * a + b;

                }
            }
        }

    }

    public class coordinate_transformation
    {
        public static void HSV2hsv(ref double[,,] arr, out double[,,] Lab, int wid, int hei)
        {
            Lab = new double[3, wid, hei];

            for (int i = 0; i < wid; i++)
            {
                for (int j = 0; j < hei; j++)
                {
                    Lab[0, i, j] = arr[0, i, j];

                    Lab[1, i, j] = arr[1, i, j];

                    Lab[2, i, j] = arr[2, i, j];

                    //--------------------------
                    Lab[0, i, j] = arr[0, i, j] * 254;

                    if (Lab[0, i, j] >= 254.0)
                    {
                        Lab[0, i, j] = 254.0 - 1.0;
                    }
                    if (Lab[0, i, j] < 0)
                    {
                        Lab[0, i, j] = 0;
                    }

                    Lab[1, i, j] = arr[1, i, j] * 254;

                    if (Lab[1, i, j] >= 254.0)
                    {
                        Lab[1, i, j] = 254.0 - 1.0;
                    }
                    if (Lab[1, i, j] < 0)
                    {
                        Lab[1, i, j] = 0;
                    }

                    Lab[2, i, j] = arr[2, i, j] * 254;

                    if (Lab[2, i, j] >= 254.0)
                    {
                        Lab[2, i, j] = 254.0 - 1.0;
                    }
                    if (Lab[2, i, j] < 0)
                    {
                        Lab[2, i, j] = 0;
                    }
                }
            }
        }
      
    }

    public class edge
    {
        public static void maxgrad_and_mingrad_HSV(ref double[,,] HSV, out int[,] ori, int num, int wid, int hei)
        {
            double[,,] Lab = new double[3, wid, hei];

            coordinate_transformation.HSV2hsv(ref HSV, out Lab, wid, hei);

            ori = new int[wid, hei];

            double gxx = 0.0, gyy = 0.0, gxy = 0.0;

            double rh = 0.0, gh = 0.0, bh = 0.0;
            double rv = 0.0, gv = 0.0, bv = 0.0;

            double theta = 0.0;

            for (int i = 1; i <= wid - 2; i++)
            {
                for (int j = 1; j <= hei - 2; j++)
                {


                    rh = (Lab[0, i - 1, j + 1] + 2 * Lab[0, i, j + 1] + Lab[0, i + 1, j + 1]) - (Lab[0, i - 1, j - 1] + 2 * Lab[0, i, j - 1] + Lab[0, i + 1, j - 1]);
                    gh = (Lab[1, i - 1, j + 1] + 2 * Lab[1, i, j + 1] + Lab[1, i + 1, j + 1]) - (Lab[1, i - 1, j - 1] + 2 * Lab[1, i, j - 1] + Lab[1, i + 1, j - 1]);
                    bh = (Lab[2, i - 1, j + 1] + 2 * Lab[2, i, j + 1] + Lab[2, i + 1, j + 1]) - (Lab[2, i - 1, j - 1] + 2 * Lab[2, i, j - 1] + Lab[2, i + 1, j - 1]);

                    //-----------------------------------------
                    rv = (Lab[0, i + 1, j - 1] + 2 * Lab[0, i + 1, j] + Lab[0, i + 1, j + 1]) - (Lab[0, i - 1, j - 1] + 2 * Lab[0, i - 1, j] + Lab[0, i - 1, j + 1]);
                    gv = (Lab[1, i + 1, j - 1] + 2 * Lab[1, i + 1, j] + Lab[1, i + 1, j + 1]) - (Lab[1, i - 1, j - 1] + 2 * Lab[1, i - 1, j] + Lab[1, i - 1, j + 1]);
                    bv = (Lab[2, i + 1, j - 1] + 2 * Lab[2, i + 1, j] + Lab[2, i + 1, j + 1]) - (Lab[2, i - 1, j - 1] + 2 * Lab[2, i - 1, j] + Lab[2, i - 1, j + 1]);

                    //---------------------------------------
                    gxx = rh * rh + gh * gh + bh * bh;
                    gyy = rv * rv + gv * gv + bv * bv;
                    gxy = rh * rv + gh * gv + bh * bv;

                    theta = Math.Round(Math.Atan(2.0 * gxy / (gxx - gyy + 0.00001)) / 2.0, 4);

                    double G1 = 0.0;
                    double G2 = 0.0;

                    G1 = Math.Sqrt(0.5 * ((gxx + gyy) + (gxx - gyy) * Math.Cos(2.0 * theta) + 2.0 * gxy * Math.Sin(2.0 * theta)));
                    G2 = Math.Sqrt(0.5 * ((gxx + gyy) + (gxx - gyy) * Math.Cos(2.0 * (theta + (Math.PI / 2.0))) + 2.0 * gxy * Math.Sin(2.0 * (theta + (Math.PI / 2.0)))));

                    double dir = 0;


                    if (Math.Max(G1, G2) == G1)
                    {
                        dir = 90.0 + theta * 180.0 / Math.PI;
                        ori[i, j] = Convert.ToInt32(dir * num / 360.0);
                    }
                    else
                    {
                        dir = 180.0 + (theta + Math.PI / 2.0) * 180.0 / Math.PI;

                        ori[i, j] = Convert.ToInt32(dir * num / 360.0);
                    }

                    if (ori[i, j] >= num - 1) ori[i, j] = num - 1;

                }
            }
        }
        public static void txQuntization(ref int[,] tx, out int[,] txq, int num, int wid, int hei)
        {
            txq = new int[wid, hei];


            for (int i = 1; i <= wid - 2; i++)
            {
                for (int j = 1; j <= hei - 2; j++)
                {
                    txq[i, j] = (tx[i, j] * num / 255);
                    if (txq[i, j] > (num - 1))
                    {
                        txq[i, j] = num - 1;
                    }
                }
            }
        }

    }
    public class Me
    {
        public static void features(ref int c, ref double[,] H , ref int [] mark , out double[,] h3)
        {

            h3 = new double[c, 124];
            for (int qq = 0; qq < 124; qq++)
            {
                for (int z = 0; z < c; z++)
                {
                    h3[z, qq] = H[z, mark[qq]];
                }
            }

        }
        public static Bitmap ResizeImage(Image image, int width, int height)
        {
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }
            return destImage;
        }
    }
        public class colordifferencehistogram
    {
        public static void computeHSVHist(ref int[,] ColorX, out double[] hist, int wid, int hei)
        {

            int[] marks = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 13, 14, 16, 17, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 32, 33, 34, 35, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161 };

            hist = new double[57];

            int i, j, k;

            for (k = 0; k < 57; k++)
            {
                for (i = 0; i <= wid - 1; i++)
                {
                    for (j = 0; j <= hei - 1; j++)
                    {

                        if (ColorX[i, j] == marks[k])
                        {
                            hist[k] += 1;

                        }

                    }
                }
            }


        }
        public static void computeHSV(ref int[,] ColorX, ref int[,] txq, ref int[,] ori, ref double[,,] HSV, out double[] hist, int wid, int hei, int CSA, int CSB, int D)
        {
            double[,,] Arr = new double[3, wid, hei];

            coordinate_transformation.HSV2hsv(ref HSV, out Arr, wid, hei);

            double[] Matrix = new double[CSA + CSB];

            hist = new double[CSA + CSB];

            //-------------------calculate the color difference of different directions------------

            int i, j;

            //----------direction=0--------------------

            for (i = 0; i <= wid - 1; i++)
            {
                for (j = 0; j <= hei - D - 1; j++)
                {
                    double value = 0.0;
                    /*
                    if (ColorX[i, j + D] == ColorX[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i, j + D] - Arr[2, i, j], 2));

                        Matrix[txq[i, j] + CSA] += value;

                    }*/
                    if (ori[i, j + D] == ori[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i, j + D] - Arr[2, i, j], 2));

                        Matrix[txq[i, j] + CSA] += value;

                    }
                    if (txq[i, j + D] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i, j + D] - Arr[2, i, j], 2));

                        Matrix[ori[i, j]] += value;
                    }
                    /*
                    if (ori[i, j + D] == ori[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i, j + D] - Arr[2, i, j], 2));

                        Matrix[ColorX[i, j]] += value;

                    }/*
                    if (ColorX[i, j + D] == ColorX[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i, j + D] - Arr[2, i, j], 2));

                        Matrix[ori[i, j] + CSA] += value;
                    }

                    if (txq[i, j + D] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i, j + D] - Arr[2, i, j], 2));

                        Matrix[ColorX[i, j]] += value;
                    }
                    */
                }
            }

            //-----------direction=90---------------------
            
            for (i = 0; i <= wid - D - 1; i++)
            {
                for (j = 0; j <= hei - 1; j++)
                {
                    double value = 0.0;

                   /* if (ColorX[i + D, j] == ColorX[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j] - Arr[2, i, j], 2));

                        Matrix[txq[i, j] + CSA] += value;

                    }*/
                    if (ori[i + D, j] == ori[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j] - Arr[2, i, j], 2));

                        Matrix[txq[i, j] + CSA] += value;

                    }
                    if (txq[i + D, j] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j] - Arr[2, i, j], 2));

                        Matrix[ori[i, j]] += value;
                    }
                    /* if (ColorX[i + D, j] == ColorX[i, j])
                     {
                         value = Math.Sqrt(Math.Pow(Arr[0, i + D, j] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j] - Arr[2, i, j], 2));

                         Matrix[ori[i, j] + CSA] += value;

                    }

                    if (txq[i+ D, j ] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j] - Arr[2, i, j], 2));

                        Matrix[ColorX[i, j]] += value;
                    }
                    */
                }
            }

            //-----------direction=135---------------------

            for (i = 0; i <= wid - D - 1; i++)
            {
                for (j = 0; j <= hei - D - 1; j++)
                {
                    double value = 0.0;

                    /*if (ColorX[i + D, j + D] == ColorX[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j + D] - Arr[2, i, j], 2));

                        Matrix[txq[i, j] + CSA] += value;

                    }
                    */
                    if (ori[i + D, j + D] == ori[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j + D] - Arr[2, i, j], 2));

                        Matrix[txq[i, j] + CSA] += value;

                    }
                    if (txq[i + D, j + D] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j + D] - Arr[2, i, j], 2));

                        Matrix[ori[i, j]] += value;
                    }
                    /* if (ColorX[i + D, j + D] == ColorX[i, j])
                     {
                         value = Math.Sqrt(Math.Pow(Arr[0, i + D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j + D] - Arr[2, i, j], 2));

                         Matrix[ori[i, j] + CSA] += value;

                   }

                    if (txq[i + D, j + D] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i + D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i + D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i + D, j + D] - Arr[2, i, j], 2));

                        Matrix[ColorX[i, j]] += value;
                    }
                    */
                }
            }

            //-----------direction=45---------------------

            for (i = D; i <= wid - 1; i++)
            {
                for (j = 0; j <= hei - D - 1; j++)
                {
                    double value = 0.0;

                   /* if (ColorX[i - D, j + D] == ColorX[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i - D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i - D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i - D, j + D] - Arr[2, i, j], 2));
                        Matrix[txq[i, j] + CSA] += value;

                    }
                    */
                    if (ori[i - D, j + D] == ori[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i - D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i - D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i - D, j + D] - Arr[2, i, j], 2));
                        Matrix[txq[i, j] + CSA] += value;

                    }
                    if (txq[i - D, j + D] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i - D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i - D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i - D, j + D] - Arr[2, i, j], 2));

                        Matrix[ori[i, j]] += value;
                    }
                    /*
                    if (ColorX[i - D, j + D] == ColorX[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i - D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i - D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i - D, j + D] - Arr[2, i, j], 2));
                        Matrix[ori[i, j] + CSA] += value;

                    }
                    if (txq[i - D, j + D] == txq[i, j])
                    {
                        value = Math.Sqrt(Math.Pow(Arr[0, i - D, j + D] - Arr[0, i, j], 2) + Math.Pow(Arr[1, i - D, j + D] - Arr[1, i, j], 2) + Math.Pow(Arr[2, i - D, j + D] - Arr[2, i, j], 2));

                        Matrix[ColorX[i, j]] += value;
                    }*/
                }
            }

            for (i = 0; i < CSA + CSB; i++)
            {

                hist[i] = (Matrix[i]) / 4.0;
                //Console.WriteLine("i:{0}\t value:{1}",i,hist[i]);

            }

        }

    }

}
