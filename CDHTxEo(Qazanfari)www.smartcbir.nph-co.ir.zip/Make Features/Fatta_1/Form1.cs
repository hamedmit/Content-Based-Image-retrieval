﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using AForge;
using AForge.Imaging;
using AForge.Imaging.ColorReduction;
using AForge.Imaging.ComplexFilters;
using AForge.Imaging.Filters;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Runtime.InteropServices;


namespace Fatta_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public List<string> imagesList = new List<string>();
        public List<string> imagesList2 = new List<string>();
        public List<String> GetImagesPath(String folderName)
        {

            DirectoryInfo Folder;

            FileInfo[] Images;

            Folder = new DirectoryInfo(folderName);
            Images = Folder.GetFiles();
            //List<string> imagesList = new List<string>();
            //Array.Sort(Images);
            for (int i = 0; i < Images.Length; i++)
            {
                imagesList.Add(string.Format(@"{0}\{1}", folderName, Images[i].Name));
            }
            return imagesList;
        }

        public List<String> GetImagesPath2(String folderName)
        {

            DirectoryInfo Folder;

            FileInfo[] Images;

            Folder = new DirectoryInfo(folderName);
            Images = Folder.GetFiles();
            //List<string> imagesList = new List<string>();
            //Array.Sort(Images);
            for (int i = 0; i < Images.Length; i++)
            {
                imagesList2.Add(string.Format(@"{0}\{1}", folderName, Images[i].Name));
            }
            return imagesList2;
        }



        public void Splashstart()
        {
            //Application.Run(new Form2());
        }
        public class MyComparer : IComparer<string>
        {

            [DllImport("shlwapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
            static extern int StrCmpLogicalW(String x, String y);

            public int Compare(string x, string y)
            {
                return StrCmpLogicalW(x, y);
            }

        }
        public double[] h1 = new double[195];
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                progressBar1.Value = 0;
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    pictureBox1.Image = (Bitmap)System.Drawing.Image.FromFile(openFileDialog1.FileName);
                }
                path3 = openFileDialog1.FileName;
                progressBar1.Visible = true;

                Thread t = new Thread(new ThreadStart(Splashstart));
                t.Start();
                progressBar1.Increment(20);
                double[] H = new double[407];



                System.Drawing.Bitmap curBitmap;
                string curFileName;
                curFileName = path3;
                string[] namenum = curFileName.Split('\\');
                string ww = namenum[namenum.Length-1];
                string[] qqq = ww.Split('.');
                int www = Convert.ToInt32(qqq[0]);
                curBitmap = new Bitmap(curFileName);
                //curBitmap = Me.ResizeImage(curBitmap, 200 , 300);
                int wid = curBitmap.Width;
                int hei = curBitmap.Height;
                int[,,] RGB = new int[3, wid, hei];
                int i, j;


                string filePath2 = "D:/Master/Thesis/Professor HassanPoor/Codes/me/Color Space/NEW/Kh2";
                GetImagesPath2(filePath2);
                allimages3 = imagesList2.ToArray();
                Array.Sort(allimages3, new MyComparer());
                System.Drawing.Bitmap curBitmap2;
                string curFileName2;
                curFileName2 = allimages3[www-1];//*******************************************************
                curBitmap2 = new Bitmap(curFileName2);
                int[,] tx = new int[wid, hei];


                for (i = 0; i < wid; i++)
                {
                    for (j = 0; j < hei; j++)
                    {
                        Color curColor;
                        curColor = curBitmap.GetPixel(i, j);
                        Color curColor2;
                        curColor2 = curBitmap2.GetPixel(i, j);

                        tx[i, j] = (int)curColor2.R;
                        RGB[0, i, j] = (int)curColor.R;
                        RGB[1, i, j] = (int)curColor.G;
                        RGB[2, i, j] = (int)curColor.B;

                    }
                }


                curBitmap.Dispose();
                curBitmap2.Dispose();
                int[,] oriHSV = new int[wid, hei];//hsv
                                                  //int[,] orilab = new int[wid, hei];//lab

                int[,] txq = new int[wid, hei];
                edge.txQuntization(ref tx, out txq, 32, wid, hei);

                int[,] ColorXHSV, ColorXHSV2 = new int[wid, hei];//HSV
                                                                 //int[,] Colorlab, Colorlab2 = new int[wid, hei];//Lab

                double[,,] HSV = new double[3, wid, hei];//hsv
                                                         //double[,,] lab = new double[3, wid, hei];//lab
                                                         //------------ We uniformly quantize the L channel into 10 bins and the a and b channels into 3 bins --------------
                progressBar1.Increment(20);
                //--------------- Orientation is quantized into 18 bins------------------------------------------------------------

                double[] histHSV = new double[407];//hsv
                                                    //double[] histlab = new double[noff];//lab

                ColorSpace.RGB2HSV(ref RGB, out HSV, wid, hei);//hsv
                                                               //ColorSpace.RGB2Lab(ref RGB, out lab, wid, hei);//lab

                ColorQuantization.cHSV(ref HSV, out ColorXHSV, 15, 5, 5, wid, hei);//hsv
                                                                                   //ColorQuantization.cLab(ref lab, out Colorlab, 5, 3, 3, wid, hei);//lab
                                                                                   //sw.Stop();

                edge.maxgrad_and_mingrad_HSV(ref HSV, out oriHSV, 36, wid, hei);//hsv
                                                                                //edge.maxgrad_and_mingrad_Lab(ref lab, out orilab, 36, wid, hei);//lab

                colordifferencehistogram.computeHSV(ref ColorXHSV, ref txq, ref oriHSV, ref HSV, out histHSV, wid, hei, 375, 32, 1);// avali = color//hsv
                                                                                                                                    //colordifferencehistogram.compute(ref Colorlab, ref txq, ref orilab, ref lab, out histlab, wid, hei, 45, looop[pp], 1);// avali = color//lab


                for (int a = 0; a < 407; a++)
                {
                    H[a] = histHSV[a];
                }

                //sw.Stop();
                progressBar1.Increment(20);

               
                //double[] ColorXHSV3 = new double[57];
                //ColorQuantization.cHSV(ref HSV, out ColorXHSV2, 18, 3, 3, wid, hei);
                //colordifferencehistogram.computeHSVHist(ref ColorXHSV2, out ColorXHSV3, wid, hei);
                //for (int a = 0; a < 57; a++)
                //{
                //    H[a + 164] = ColorXHSV3[a];
                //}
                progressBar1.Increment(20);
                int[] marks2 = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 76, 77, 78, 79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 383, 384, 385, 386, 387, 388, 389, 391, 393, 394, 395, 396, 397, 398, 401, 402, 403, 404, 406 };
                for (int qq = 0; qq < 195; qq++)
                {
                    h1[qq] = H[marks2[qq]];

                }
                progressBar1.Increment(20);
                MessageBox.Show("تبریک... استخراج ویژگی ها به پایان رسید. حال میتوانید بازیابی تصاویر را انجام دهید", "استخراج ویژگی ها");
                progressBar1.Visible = false;
                button2.Enabled = true;
                button4.Enabled = true;
                if (g == 1) {
                    button2.Enabled = false;
                    button4.Enabled = false;
                }
            }
            catch {
                Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                button4.Enabled = false;
                MessageBox.Show("لطفا ابتدا پوشه تصاویر را انتخاب کنید", "انتخاب فایل ویژگی ها و پوشه تصاویر");
                string filePath;
                using (var folderDialog = new FolderBrowserDialog())
                {
                    if (folderDialog.ShowDialog() == DialogResult.OK)
                    {

                        // folderDialog.SelectedPath -- your result
                    }
                    filePath = folderDialog.SelectedPath;
                }

                //List<string> imagesList2 = new List<string>();
                GetImagesPath(filePath);

                allimages = imagesList.ToArray();
                Array.Sort(allimages, new MyComparer());
                MessageBox.Show("لطفا اکنون فایل ویژگی تصاویر را انتخاب کنید", "انتخاب فایل ویژگی ها و پوشه تصاویر");
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    double[,] h3 = new double[imagesList.Count, 124];
                    int d = 0;
                    var reader = new StreamReader(File.OpenRead(openFileDialog1.FileName));
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();

                        var values = line.Split(',');
                        if (values.Length - 1 != imagesList.Count)
                        {
                            MessageBox.Show("فایلها بدرستی انتخاب نشده است. لطفا مجدد تلاش کنید.", "عدم تطبیق ویژگی ها و تصاویر");
                            Close();
                        }
                        for (int qq = 0; qq < imagesList.Count; qq++)
                        {
                            if (qq > imagesList.Count)
                            {
                                MessageBox.Show("فایلها بدرستی انتخاب نشده است. لطفا مجدد تلاش کنید.", "عدم تطبیق ویژگی ها و تصاویر");
                                Close();
                            }
                            h3[qq, d] = Convert.ToDouble(values[qq]);
                        }

                        d++;
                    }
                    path2 = openFileDialog1.FileName;
                    if (d != 124)
                    {
                        MessageBox.Show("فایلها بدرستی انتخاب نشده است. لطفا مجدد تلاش کنید.", "عدم تطبیق ویژگی ها و تصاویر");
                        Close();
                    }

                    else MessageBox.Show("تبریک، فایلها بدرستی انتخاب شده است", " تطبیق ویژگی ها و تصاویر");
                    //pictureBox2.Image = AForge.Imaging.Image.FromFile("D:/Thesis/Professor HassanPoor/Codes/me/Color Space/Me/1.jpg");
                }
                button3.Enabled = true;
            }
            catch { Close(); }

        }

        public int[] index2;

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                double[,] h3 = new double[imagesList.Count, 124];
                int d = 0;
                string p;
                if (b == 1)
                    p = path1;
                else p = path2;

                var reader = new StreamReader(File.OpenRead(p));
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();

                    var values = line.Split(',');
                    if (values.Length - 1 != imagesList.Count)
                    {
                        MessageBox.Show("فایلها بدرستی انتخاب نشده است. لطفا مجدد تلاش کنید.", "عدم تطبیق ویژگی ها و تصاویر");
                        Close();
                    }
                    for (int qq = 0; qq < imagesList.Count; qq++)
                    {
                        if (qq > imagesList.Count)
                        {
                            MessageBox.Show("فایلها بدرستی انتخاب نشده است. لطفا مجدد تلاش کنید.", "عدم تطبیق ویژگی ها و تصاویر");
                            Close();
                        }
                        h3[qq, d] = Convert.ToDouble(values[qq]);
                    }

                    d++;
                }
                int[] index = new int[imagesList.Count];
                for (int ko = 0; ko < index.Length; ko++)
                    index[ko] = ko;
                double[] dis = new double[imagesList.Count];
                double MQ1 = 0, MU2 = 0, MQ2 = 0, MU1 = 0, MQ3 = 0, MU3 = 0;
                double DD1 = 0, t0 = 0, t1 = 0, t2 = 0, DD2 = 0, DD3 = 0, DD4 = 0;

                for (int t = 0; t < imagesList.Count; t++)
                {
                    MQ1 = 0; MU1 = 0; MQ2 = 0; MU2 = 0; MQ3 = 0; MU3 = 0;

                    t0 = t1 = t2 = DD1 = 0;
                    for (int q = 0; q < 52; q++)
                    {

                        MQ1 = MQ1 + h1[q];
                        MU1 = MU1 + h3[t, q];
                    }
                    MQ1 = MQ1 / 52;
                    MU1 = MU1 / 52;
                    DD1 = 0; t0 = 0; t1 = 0; t2 = 0;
                    for (int q = 0; q < 52; q++)
                    {
                        t0 = Math.Abs(h1[q] - h3[t, q]);
                        t1 = Math.Abs(h1[q] + MQ1);
                        t2 = Math.Abs(h3[t, q] + MU1);
                        DD1 = DD1 + (t0 / (t1 + t2));
                    }
                    MQ2 = 0; MU2 = 0;
                    for (int q = 52; q < 67; q++)
                    {

                        MQ2 = MQ2 + h1[q];
                        MU2 = MU2 + h3[t, q];
                    }
                    MQ2 = MQ2 / 15;
                    MU2 = MU2 / 15;
                    DD2 = 0; t0 = 0; t1 = 0; t2 = 0;
                    for (int q = 52; q < 67; q++)
                    {
                        t0 = Math.Abs(h1[q] - h3[t, q]);
                        t1 = Math.Abs(h1[q] + MQ2);
                        t2 = Math.Abs(h3[t, q] + MU2);
                        DD2 = DD2 + (t0 / (t1 + t2));
                    }


                    MQ3 = 0; MU3 = 0;
                    t0 = t1 = t2 = DD3 = 0;
                    for (int q = 67; q < 124; q++)
                    {

                        MQ3 = MQ3 + h1[q];
                        MU3 = MU3 + h3[t, q];
                    }
                    MQ3 = MQ3 / 57;
                    MU3 = MU3 / 57;

                    for (int q = 67; q < 124; q++)
                    {
                        t0 = Math.Abs(h1[q] - h3[t, q]);
                        t1 = Math.Abs(h1[q] + MQ3);
                        t2 = Math.Abs(h3[t, q] + MU3);
                        DD3 = DD3 + (t0 / (t1 + t2));
                    }

                    dis[t] = 0.2 * DD1 + 0.65 * DD2 + 0.15 * DD3;
                    DD2 = DD1 = DD3 = DD4 = 0;

                }
                Array.Sort(dis, index);
                index2 = index;
                pictureBox2.Image = AForge.Imaging.Image.FromFile(allimages[index[0]]);

                pictureBox3.Image = AForge.Imaging.Image.FromFile(allimages[index[1]]);

                pictureBox4.Image = AForge.Imaging.Image.FromFile(allimages[index[2]]);

                pictureBox5.Image = AForge.Imaging.Image.FromFile(allimages[index[3]]);

                pictureBox6.Image = AForge.Imaging.Image.FromFile(allimages[index[4]]);

                pictureBox7.Image = AForge.Imaging.Image.FromFile(allimages[index[5]]);

                pictureBox8.Image = AForge.Imaging.Image.FromFile(allimages[index[6]]);

                pictureBox9.Image = AForge.Imaging.Image.FromFile(allimages[index[7]]);

                pictureBox10.Image = AForge.Imaging.Image.FromFile(allimages[index[8]]);

                pictureBox11.Image = AForge.Imaging.Image.FromFile(allimages[index[9]]);

                pictureBox12.Image = AForge.Imaging.Image.FromFile(allimages[index[10]]);

                pictureBox13.Image = AForge.Imaging.Image.FromFile(allimages[index[11]]);

                pictureBox14.Image = AForge.Imaging.Image.FromFile(allimages[index[12]]);

                pictureBox15.Image = AForge.Imaging.Image.FromFile(allimages[index[13]]);

                pictureBox16.Image = AForge.Imaging.Image.FromFile(allimages[index[14]]);

                pictureBox17.Image = AForge.Imaging.Image.FromFile(allimages[index[15]]);

                pictureBox18.Image = AForge.Imaging.Image.FromFile(allimages[index[16]]);

                pictureBox19.Image = AForge.Imaging.Image.FromFile(allimages[index[17]]);
                pictureBox2.Enabled = true;
                pictureBox3.Enabled = true;
                pictureBox4.Enabled = true;
                pictureBox5.Enabled = true;
                pictureBox6.Enabled = true;
                pictureBox7.Enabled = true;
                pictureBox8.Enabled = true;
                pictureBox9.Enabled = true;
                pictureBox10.Enabled = true;
                pictureBox11.Enabled = true;
                pictureBox12.Enabled = true;
                pictureBox13.Enabled = true;
                pictureBox14.Enabled = true;
                pictureBox15.Enabled = true;
                pictureBox16.Enabled = true;
                pictureBox17.Enabled = true;
                pictureBox18.Enabled = true;
                pictureBox19.Enabled = true;
                button4.Enabled = false;
                button2.Enabled = false;
                g = 1;
            }
            catch { Close(); }


        }
        public string path, path1, path2, path3;
        public int g = 0;
        private void pictureBox12_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[10]]);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[11]]);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[0]]);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[1]]);
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[2]]);
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[3]]);
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[4]]);
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[5]]);
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[6]]);
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[7]]);
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[8]]);
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[9]]);
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[12]]);
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[13]]);
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[14]]);
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[15]]);
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[16]]);
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
            Process.Start(allimages[index2[17]]);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public int b = 0;
        public string[] allimages;
        public string[] allimages2;
        public string[] allimages3;
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                button2.Enabled = false;
                progressBar1.Value = 0;
                MessageBox.Show("لطفا پوشه تصاویر مورد نظر را انتخاب کنید", "انتخاب پوشه تصاویر تصاویر");
                string filePath;
                using (var folderDialog = new FolderBrowserDialog())
                {
                    if (folderDialog.ShowDialog() == DialogResult.OK)
                    {

                        // folderDialog.SelectedPath -- your result
                    }
                    filePath = folderDialog.SelectedPath;
                }
                GetImagesPath(filePath);
                path = filePath;
                MessageBox.Show("پوشه تصاویر انتخاب شد. لطفا جهت استخراج ویژگی های تصاویر، دکمه تایید را انتخاب کنید و لطفا شکیبا باشید", "استخراج ویژگی ها");
                progressBar1.Visible = true;

                Thread t = new Thread(new ThreadStart(Splashstart));
                t.Start();

                
                string jj;
                
                allimages = imagesList.ToArray();
                Array.Sort(allimages, new MyComparer());
                progressBar1.Increment(1);
                int inc = imagesList.Count / 100;

                string filePath2= "D:/Master/Thesis/Professor HassanPoor/Codes/me/Color Space/NEW/Kh2";
                GetImagesPath2(filePath2);
                allimages2 = imagesList2.ToArray();
                Array.Sort(allimages2, new MyComparer());
                //int[] looop= new int[1] {8};
                for (int pp=0; pp<1; pp++)
                {
                    int noff = 36 + 16;
                    double[,] H = new double[imagesList.Count, noff];
                    for (int ii = 0; ii < imagesList.Count; ii++)
                    {
                        //myInt2 = ii;
                        if (ii % inc == 0)
                            progressBar1.Increment(1);

                        jj = Convert.ToString(ii);
                        System.Drawing.Bitmap curBitmap;
                        string curFileName;
                        curFileName = allimages[ii];
                        curBitmap = new Bitmap(curFileName);
                        int wid = curBitmap.Width;
                        int hei = curBitmap.Height;
                        int[,,] RGB = new int[3, wid, hei];
                        int i, j;

                        System.Drawing.Bitmap curBitmap2;
                        string curFileName2;
                        curFileName2 = allimages2[ii];
                        curBitmap2 = new Bitmap(curFileName2);
                        int[,] tx = new int[wid, hei];


                        for (i = 0; i < wid; i++)
                        {
                            for (j = 0; j < hei; j++)
                            {
                                Color curColor;
                                curColor = curBitmap.GetPixel(i, j);
                                Color curColor2;
                                curColor2 = curBitmap2.GetPixel(i, j);

                                tx[i, j] = (int)curColor2.R;
                                RGB[0, i, j] = (int)curColor.R;
                                RGB[1, i, j] = (int)curColor.G;
                                RGB[2, i, j] = (int)curColor.B;

                            }
                        }


                        curBitmap.Dispose();
                        curBitmap2.Dispose();
                        int[,] oriHSV = new int[wid, hei];//hsv
                        //int[,] orilab = new int[wid, hei];//lab

                        int[,] txq = new int[wid, hei];
                        edge.txQuntization(ref tx, out txq, 16, wid, hei);

                        int[,] ColorXHSV, ColorXHSV2 = new int[wid, hei];//HSV
                        //int[,] Colorlab, Colorlab2 = new int[wid, hei];//Lab

                        double[,,] HSV = new double[3, wid, hei];//hsv
                        //double[,,] lab = new double[3, wid, hei];//lab
                        //------------ We uniformly quantize the L channel into 10 bins and the a and b channels into 3 bins --------------
                        //--------------- Orientation is quantized into 18 bins------------------------------------------------------------

                        double[] histHSV = new double[noff];//hsv
                        //double[] histlab = new double[noff];//lab

                        ColorSpace.RGB2HSV(ref RGB, out HSV, wid, hei);//hsv
                        //ColorSpace.RGB2Lab(ref RGB, out lab, wid, hei);//lab

                        ColorQuantization.cHSV(ref HSV, out ColorXHSV, 8, 3, 3, wid, hei);//hsv
                        //ColorQuantization.cLab(ref lab, out Colorlab, 5, 3, 3, wid, hei);//lab
                        //sw.Stop();

                        edge.maxgrad_and_mingrad_HSV(ref HSV, out oriHSV, 36, wid, hei);//hsv
                        //edge.maxgrad_and_mingrad_Lab(ref lab, out orilab, 36, wid, hei);//lab

                        colordifferencehistogram.computeHSV(ref ColorXHSV, ref txq, ref oriHSV, ref HSV, out histHSV, wid, hei, 36, 16, 1);// avali = color//hsv
                        //colordifferencehistogram.compute(ref Colorlab, ref txq, ref orilab, ref lab, out histlab, wid, hei, 45, looop[pp], 1);// avali = color//lab


                        for (int a = 0; a < noff; a++)
                        {
                            H[ii, a] = histHSV[a];
                        }
                        Console.WriteLine("i:{0}", ii);
                        Console.WriteLine("i:{0}", 32);
                        /*
                        double[] ColorXHSV3 = new double[57];
                        ColorQuantization.cHSV(ref HSV, out ColorXHSV2, 18, 3, 3, wid, hei);
                        colordifferencehistogram.computeHSVHist(ref ColorXHSV2, out ColorXHSV3, wid, hei);
                        for (int a = 0; a < 57; a++)
                        {
                            H[ii, a + 164] = ColorXHSV3[a];
                            //Console.WriteLine("H:{0}", hist[a]);
                        }
                        //if (progressBar1.Value == 100)
                        //timer1.Stop();*/
                    }
                
                    StreamWriter Writer22 = null;
                    //string Name3 = @"Finalt1.csv";
                    string Name2 = @" " + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".csv";
                    path1 = Name2;
                    // Create a new stream to write to the file
                    Writer22 = new StreamWriter(File.OpenWrite(Name2));

                    //int[] marks2 = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 132, 134, 135, 136, 137, 138, 139, 140, 142, 150, 151, 152, 154, 155, 156, 158, 159, 160, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220 };
                    double[,] h3 = new double[imagesList.Count, noff];
                    for (int qq = 0; qq < noff; qq++)
                    {
                        for (int z = 0; z < imagesList.Count; z++)
                        {
                            h3[z, qq] = H[z, qq];
                            Writer22.Write(H[z, qq]);
                            Writer22.Write(',');
                        }
                        Writer22.Write('\n');
                        // Console.WriteLine("i:{0}", qq);
                        //Console.WriteLine("H:{0}", H[z, qq]);
                    }
                    Writer22.Flush();
                    Writer22.Close();

                }



                Thread.Sleep(200);
                t.Abort();
                progressBar1.Visible = false;
                MessageBox.Show("تبریک... استخراج ویژگی ها به پایان رسید. حال میتوانید بازیابی تصاویر را انجام دهید", "استخراج ویژگی ها");
                b = 1;
                button3.Enabled = true;
            }
            catch (DivideByZeroException error) { Console.WriteLine(error.Message); Close();  }
        }
    }
}
